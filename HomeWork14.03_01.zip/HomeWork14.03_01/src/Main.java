import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите число: ");
        int number = scr.nextInt();
        System.out.println("Первое число: " + (number / 100));
        System.out.println("Второе число: " + (number / 10 % 10));
        System.out.println("Третье число: " + (number % 10));
    }
}