import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int number1 = rnd.nextInt(999);
        int number2 = rnd.nextInt(999);
        int number3 = rnd.nextInt(999);
        System.out.println("Сумма: " + (number1 + number2 + number3));
        System.out.println("Произведение: " + number1 * number2 * number3);
    }
}